package TEST0504;

import java.util.ArrayList;
public class Main {
    public static void main(String[] args) {
        ArrayList<Integer> al = new ArrayList<>();
        int num;

        while(al.size()<3) {
            num = (int)(Math.random() * 99)+1;
            if(al.indexOf(num) == -1) {
                al.add(num);
            }
        }
        System.out.println(al);
    }
}